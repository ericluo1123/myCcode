
#ifndef _Select_File_H_
#define _Select_File_H_

#define true        1
#define false       0
#define enable      1
#define disable     0
 
#include "../2-1.PIR_Ceiling_Embed.X/Select_File.h"

#endif