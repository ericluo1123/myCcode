
#ifndef _Select_File_H_
#define _Select_File_H_

#define true        1
#define false       0
#define enable      1
#define disable     0

#include "../2-1.PIR_Ceiling_Embed.X/PIR_Ceiling_Embed_V1.1.2.1.3.h"

#endif